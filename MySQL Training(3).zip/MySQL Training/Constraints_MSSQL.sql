-- Primary Key
ALTER TABLE Persons
ADD CONSTRAINT pk_PersonID PRIMARY KEY (P_Id,LastName)

-- Foreign key
ALTER TABLE Orders
ADD CONSTRAINT fk_PerOrders FOREIGN KEY (P_Id) REFERENCES Persons(P_Id)

-- Unique Key
ALTER TABLE Persons
ADD CONSTRAINT uc_PersonID UNIQUE (P_Id,LastName)

-- Default 
 ALTER TABLE Persons
ALTER COLUMN City SET DEFAULT 'abc'