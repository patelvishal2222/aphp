

CREATE TABLE [UM].[UserRole](
	[UserRoleID] [int] IDENTITY(1,1) NOT NULL,
	[UserID] [int] NOT NULL,
	[ServiceID] [smallint] NOT NULL DEFAULT ((0)),
	[RoleID] [int] NOT NULL,
	[InsertedBy] [int] NOT NULL,
	[InsertedDate] [date] NOT NULL,
 CONSTRAINT [PK__UserRole__UserRoleID] PRIMARY KEY CLUSTERED 
(
	[UserRoleID] ASC
)
)

GO

ALTER TABLE [UM].[UserRole]  WITH CHECK ADD  CONSTRAINT [FK__UserRole__UserMaster] FOREIGN KEY([UserID])
REFERENCES [UM].[UserMaster] ([UserID])
GO

-- Indexes
EXEC SP_HELPINDEX '[UM].[UserRole]'
GO


-- reseed identity
DBCC CHECKIDENT ('UM.UserRole', RESEED, 100)
GO
