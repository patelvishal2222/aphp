DELIMITER ;;
CREATE DEFINER=`UM`@`%` PROCEDURE `Get_RoleFunctionality_UniqueyKey`(
	ServiceID	SMALLINT,
	ClientID	INT,
	RoleID		INT,
	dtRoleFunctionality TEXT,
	OUT RoleKey VARCHAR(2000),
	OUT ReturnMessage VARCHAR(1000),
	OUT RowCount INT
)
BEGIN
/* 
    Procedure Header:
        +-----------------------------------------------------------------------+
          Procedure Name       Get_RoleFunctionality_UniqueyKey
          Purpose              To Get unique for role functionality combination
          Created By           Mayank Kukadia
          Created Date         08/30/2015
          JIRA Id               --
         -------  Parameter Details ----------------------------------------
          @ServiceID            ForeignKey of ServiceMaster PrimeryKey.
		  @ClientID				ForeignKey of ClientService PrimeryKey
		  @RoleID				ForeignKey of ClientService PrimeryKey
          @ReturnMessage        OUTPUT - returns output message of procedure
		  @RowCount				OUTPUT - return numbers of row
        +-----------------------------------------------------------------------+
    
    Script with Sample parameters:
        +-----------------------------------------------------------------------+
          EXEC Get_RoleFunctionality_UniqueyKey @ServiceID = 2, @ClientID=NULL, @RoleID=NULL, @ReturnMessage=0
        +-----------------------------------------------------------------------+

    Revision History:(Latest First)
        +-----------------------------------------------------------------------+
          Modified By        Modified Date  JIRA Id     Purpose
          -----------------  -------------- ----------- ------------------------          
        +-----------------------------------------------------------------------+
*/
		
		DECLARE ServiceID_ SMALLINT  DEFAULT ServiceID;
		DECLARE ClientID_	INT DEFAULT IFNULL(ClientID,0);
		DECLARE RoleID_	INT DEFAULT IFNULL(RoleID,0);
		
        
        
		DECLARE Counter_ INT DEFAULT 0;
        DECLARE I INT DEFAULT 1;
        DECLARE XML_DATA TEXT DEFAULT dtRoleFunctionality;
  		
  		DECLARE code CHAR(5) DEFAULT '00000';
  		DECLARE msg TEXT; 
          
  		DECLARE EXIT HANDLER FOR SQLEXCEPTION
  		BEGIN
  		GET DIAGNOSTICS CONDITION 1
  		code = RETURNED_SQLSTATE, msg = MESSAGE_TEXT;
  		SET ReturnMessage = msg;
  		END;   
  	
		SET SESSION group_concat_max_len = 1000000;
        
		CREATE TEMPORARY TABLE IF NOT EXISTS TempRoleFunctionalityTable(RoleFunctionalityID int NOT NULL AUTO_INCREMENT PRIMARY KEY, ServiceID Int,RoleID Int, FunctionalityID Int, ScreenID INT, ScreenFunctionalityID INT, InsertedBy INT);
	    DELETE FROM TempRoleFunctionalityTable;
  
		SET Counter_ = EXTRACTVALUE(XML_DATA, 'COUNT(/RoleFunctionality/Row)');		
        
          WHILE (I <= Counter_) DO 
          
               INSERT INTO TempRoleFunctionalityTable
  				(
  					ServiceID,
  					RoleID,
  					FunctionalityID,
  					ScreenID,
  					ScreenFunctionalityID,
  					InsertedBy
  				)
                  SELECT 
  					NULLIF(EXTRACTVALUE(XML_DATA, '/RoleFunctionality/Row[$I]/ServiceID'),''),
  					NULLIF(EXTRACTVALUE(XML_DATA, '/RoleFunctionality/Row[$I]/RoleID'),''),
  					NULLIF(EXTRACTVALUE(XML_DATA, '/RoleFunctionality/Row[$I]/FunctionalityID'),''),
  					NULLIF(EXTRACTVALUE(XML_DATA, '/RoleFunctionality/Row[$I]/ScreenID'),''),
  					NULLIF(EXTRACTVALUE(XML_DATA, '/RoleFunctionality/Row[$I]/ScreenFunctionalityID'),''),
  					NULLIF(EXTRACTVALUE(XML_DATA, '/RoleFunctionality/Row[$I]/InsertedBy'),'');
                      
  			SET I= I + 1;
          
          END WHILE;
		  	
				SET @XML = '';
				SELECT GROUP_CONCAT(CONCAT(@XML,CONCAT(
									'<Row>',
									IFNULL(CONCAT('<SeId>',A.SeId,'</SeId>'),''),
									IFNULL(CONCAT('<FnId>',A.FnId,'</FnId>'),''),
									IFNULL(CONCAT('<ScId>',A.ScId,'</ScId>'),''),
									IFNULL(CONCAT('<SfId>',A.SfId,'</SfId>'),''),
									'</Row>'))) AS TEST INTO  @XML
				FROM 
					(
					SELECT 
						DISTINCT Temp.ServiceID SeId, Temp.FunctionalityID FnId, Temp.ScreenID ScId, Temp.ScreenFunctionalityID  SfId 
					FROM TempRoleFunctionalityTable Temp 
                    
					) AS A
				ORDER BY A.FnId, A.ScId, A.SfId;

				SET RoleKey :=  @XML;
				
				SET RoleID_  = (SELECT  
					 DISTINCT rf.RoleID
				FROM RoleMaster rf 
				GROUP BY rf.RoleID
				LIMIT 1);
        
		SET RowCount = ROW_COUNT();

END ;;