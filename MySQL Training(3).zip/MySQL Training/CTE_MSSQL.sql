
CREATE PROCEDURE [UM].[Get_ActiveSessions]
(
   @CurrentUserID INT,
   @LoginIPAddress varchar(128) = NULL,
   @UserName varchar(50) = NULL,
   @RowCount INT OUTPUT,
   @ReturnMessage VARCHAR(1000) OUTPUT
)
AS
/*
	Procedure Header:
	+-----------------------------------------------------------------------+
	Procedure Name       [UM].[Get_ActiveSessions]
	Purpose               To Get all ActiveSession
	Created By            Mayank Kukadia
	Created Date          2015-07-02
	JIRA Id               --

	-------  Parameter Details ----------------------------------------
	@CurrentUserID		Cuurent User's ID 		
	@LoginIPAddress 	Cuurent User's IPAddress
	@UserName 			User's UserName
	@ReturnMessage      OUTPUT - returns output message of procedure
	@RowCount			OUTPUT - return numbers of row		
	+-----------------------------------------------------------------------+
    
	Script with Sample parameters:
	+-----------------------------------------------------------------------+
	EXEC [UM].[Get_ActiveSessions]  
	@CurrentUserID=1,	
	@LoginIPAddress ='', 
	@UserName='', 							
	@ReturnMessage = '',	 
	@RowCount = 0                               
	+-----------------------------------------------------------------------+

	Revision History:(Latest First)
	+-----------------------------------------------------------------------+
	Modified By        Modified Date  JIRA Id     Purpose
	-----------------  -------------- ----------- ------------------------
          
	+-----------------------------------------------------------------------+
	*/
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	
	DECLARE @CurrentUserID_ INT = @CurrentUserID;
	DECLARE @ChildRoles TABLE( ID INT PRIMARY KEY IDENTITY, ParentRoleID INT );

	;WITH ParentRole
                 AS (
                 SELECT DISTINCT RM.RoleID AS RoleID,
                        RM.RoleName AS RoleName,
                        0 AS ParentRoleID
                 FROM UM.RoleMaster RM
                      INNER JOIN UM.UserRole AS UR ON UR.RoleID = RM.RoleID
                 WHERE UR.UserID = @CurrentUserID_
                 UNION ALL
                 SELECT CHLD.RoleID AS RoleID,
                        CHLD.RoleName AS RoleName,
                        PRNT.RoleID AS ParentRoleID
                 FROM ParentRole AS PRNT
                      INNER JOIN UM.RoleMaster AS CHLD ON PRNT.RoleID = CHLD.ParentRoleID )
	   
		/*
	   INSERT INTO @ChildRoles
                    SELECT DISTINCT ParentRole.RoleID
                    FROM ParentRole
				LEFT JOIN UM.UserRole ON UM.UserRole.RoleID = ParentRole.RoleID
				AND UM.UserRole.UserID = @CurrentUserID_
				WHERE ISNULL(UM.UserRole.RoleID,0) = 0;

	   SELECT DISTINCT rtrim(ltrim(um.FirstName )) + ' ' + rtrim(ltrim(um.LastName )) AS FullName,
	       um.UserName ,
	       li.LoginIPAddress,
	       li.LoginDate,
	       li.Browser,
	       li.SystemPlatform,
	       li.RemoteIPAddress,
	       li.WindowsLoginUser,
	       li.TotalTimeInSeconds,
		  li.LoginInfoID,
		  li.TokenID
	   
	   FROM UM.LoginInfo li
	   INNER JOIN UM.UserMaster UM ON UM.UserID = li.UserID
	   	   AND UM.IsActive = li.IsActive
	   INNER JOIN UM.UserRole UR ON UR.UserID = UM.UserID
	   INNER JOIN @ChildRoles ON [@ChildRoles].ParentRoleID = UR.RoleID
	   WHERE li.IsActive = 1
	   AND li.LoginIPAddress like isnull(@LoginIPAddress , li.LoginIPAddress) + '%'
	   AND um.UserName LIKE '%' + isnull(@UserName , um.UserName)+'%'
	   */
	   
END

