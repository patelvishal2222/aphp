CREATE TRIGGER before_employee_update 
    ON employees
    AFTER UPDATE 
AS
BEGIN
    INSERT INTO employees_audit
    SET action = 'update',
     employeeNumber = OLD.employeeNumber,
        lastname = OLD.lastname,
        changedat = GETDATE(); 
END