-- Primary Key
ALTER TABLE Persons
ADD PRIMARY KEY (P_Id)

-- Foreign key
ALTER TABLE Orders
ADD FOREIGN KEY (P_Id) REFERENCES Persons(P_Id)

-- Unique Key
ALTER TABLE Persons
ADD UNIQUE (P_Id)

-- Default  
ALTER TABLE Persons
ALTER City SET DEFAULT 'abc'