create PROCEDURE [UM].[Get_RoleFunctionality_UniqueyKey]
(
	@ServiceID	SMALLINT,
	@ClientID	INT=NULL,
	@RoleID		INT=NULL,
	@dtRoleFunctionality UM_RoleFunctionality ReadOnly,
	@RoleKey VARCHAR(MAX) = NULL OUTPUT,
	@ReturnMessage VARCHAR(1000)=NULL OUTPUT,
	@RowCount INT=0 OUTPUT
)
/*
    Procedure Header:
        +-----------------------------------------------------------------------+
          Procedure Name       [UM].[Get_RoleFunctionality_UniqueyKey]
          Purpose              To Get unique for role functionality combination
          Created By           Mayank Kukadia
          Created Date         08/30/2015
          JIRA Id               --
         -------  Parameter Details ----------------------------------------
          @ServiceID            ForeignKey of ServiceMaster PrimeryKey.
		  @ClientID				ForeignKey of ClientService PrimeryKey
		  @RoleID				ForeignKey of ClientService PrimeryKey
          @ReturnMessage        OUTPUT - returns output message of procedure
		  @RowCount				OUTPUT - return numbers of row
        +-----------------------------------------------------------------------+
    
    Script with Sample parameters:
        +-----------------------------------------------------------------------+
          EXEC [UM].[Get_RoleFunctionality_UniqueyKey] @ServiceID = 2, @ClientID=NULL, @RoleID=NULL, @ReturnMessage=0
        +-----------------------------------------------------------------------+

    Revision History:(Latest First)
        +-----------------------------------------------------------------------+
          Modified By        Modified Date  JIRA Id     Purpose
          -----------------  -------------- ----------- ------------------------          
        +-----------------------------------------------------------------------+
*/
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	SET @ReturnMessage = ''
	SET @RowCount=0
	BEGIN TRY
		DECLARE @ServiceID_ SMALLINT=@ServiceID
		DECLARE @ClientID_	INT=ISNULL(@ClientID,0)
		DECLARE @RoleID_	INT=ISNULL(@RoleID,0)
		DECLARE @TempRoleFunctionalityTable TABLE(RoleFunctionalityID int IDENTITY PRIMARY KEY, ServiceID SMALLINT, RoleID INT,FunctionalityID INT, ScreenID INT, ScreenFunctionalityID INT, InsertedBy INT)
		/* all Data Inserted into temp table  */
		INSERT INTO @TempRoleFunctionalityTable
		(	ServiceID,
			RoleID,
			FunctionalityID,
			ScreenID,
			ScreenFunctionalityID,
			InsertedBy
		)
		SELECT @ServiceID_,
			RoleID,
			FunctionalityID,
			ScreenID,
			ScreenFunctionalityID,
			InsertedBy
		FROM @dtRoleFunctionality;
				
			SELECT DISTINCT TOP 1 @RoleID_= rf.RoleID,
			@RoleKey =(SELECT DISTINCT Temp.ServiceID SeId, Temp.FunctionalityID FnId, Temp.ScreenID ScId, Temp.ScreenFunctionalityID  SfId
				From @TempRoleFunctionalityTable Temp 
				ORDER BY Temp.ServiceID, Temp.FunctionalityID, Temp.ScreenID, Temp.ScreenFunctionalityID
				FOR XML PATH('Row')
			)
			FROM UM.RoleMaster rf 
			GROUP BY rf.RoleID
		SET @RowCount= @@ROWCOUNT
    END TRY
	BEGIN CATCH
		SET @ReturnMessage = [UM].GetErrorDetails();	
	END CATCH
END

