DELIMITER ;;
CREATE DEFINER=`UM`@`%` PROCEDURE `Get_ActiveSessions`(
   IN CurrentUserID INT,
   IN LoginIPAddress varchar(128) ,
   IN UserName varchar(50),
   OUT RowCount INT ,
   OUT ReturnMessage VARCHAR(1000) 
)
BEGIN

	DECLARE CTEDone TINYINT UNSIGNED DEFAULT 0;
    DECLARE Level_ SMALLINT UNSIGNED DEFAULT 0;
	DECLARE CurrentUserID_ INT DEFAULT CurrentUserID;
    DECLARE UserName_ varchar(50) DEFAULT UserName;
    DECLARE LoginIPAddress_ varchar(128)  DEFAULT LoginIPAddress;
    
    DECLARE code CHAR(5) DEFAULT '00000';
	DECLARE msg TEXT; 
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
		BEGIN
		GET DIAGNOSTICS CONDITION 1
		code = RETURNED_SQLSTATE, msg = MESSAGE_TEXT;
		SET ReturnMessage = msg;
	END;   

	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	
	CREATE TEMPORARY TABLE IF NOT EXISTS ChildRoles ( ID INT PRIMARY KEY AUTO_INCREMENT, ParentRoleID INT );
    
    CREATE TEMPORARY TABLE IF NOT EXISTS ParentRole ( ParentRoleID INT, RoleID INT, RoleName varchar(256), Level smallint);
	CREATE TEMPORARY TABLE IF NOT EXISTS ParentRole_Temp ( ParentRoleID INT, RoleID INT, RoleName varchar(256), Level smallint);
	
    TRUNCATE TABLE  ChildRoles;
	TRUNCATE TABLE ParentRole;
	TRUNCATE TABLE  ParentRole_Temp;
    
	INSERT INTO ParentRole (ParentRoleID,RoleID,RoleName,Level)
	SELECT 0 AS ParentRoleID,
			RM.RoleID AS RoleID,
			RM.RoleName AS RoleName,
		    Level_ AS Level
	FROM RoleMaster RM
	INNER JOIN UserRole AS UR ON UR.RoleID = RM.RoleID
	WHERE UR.UserID = CurrentUserID_;
      
    WHILE NOT CTEDone DO
	IF ( SELECT 1 = 1 FROM ParentRole AS PRNT
		INNER JOIN RoleMaster AS CHLD 
			ON PRNT.RoleID = CHLD.ParentRoleID 
			AND PRNT.Level = Level_ LIMIT 1) 
        THEN
			
            SET Level_ = Level_ +  1;
            
			INSERT INTO ParentRole_Temp (ParentRoleID,RoleID,RoleName,Level)
			SELECT  PRNT.RoleID AS ParentRoleID,
					CHLD.RoleID AS RoleID,
					CHLD.RoleName AS RoleName,
					Level_ AS Level
			 FROM ParentRole AS PRNT
			INNER JOIN RoleMaster AS CHLD 
				  ON PRNT.RoleID = CHLD.ParentRoleID 
				  AND PRNT.Level = Level_ - 1;
                  
		INSERT INTO ParentRole (ParentRoleID,RoleID,RoleName,Level) 
		SELECT  ParentRoleID,RoleID,RoleName,Level  FROM ParentRole_Temp WHERE ParentRole_Temp.Level = Level_;
             		
		ELSE
			SET CTEDone = 1;
		END IF;
   END WHILE;    
        
       
		INSERT INTO ChildRoles(ParentRoleID)
		SELECT DISTINCT ParentRole.RoleID
			FROM ParentRole
		LEFT JOIN UserRole ON UserRole.RoleID = ParentRole.RoleID
		AND UserRole.UserID = CurrentUserID_
		WHERE IFNULL(UserRole.RoleID,0) = 0;
       
       
      SELECT 
		   DISTINCT CONCAT(rtrim(ltrim(FirstName )) , ' ' , rtrim(ltrim(LastName ))) AS FullName,
	       um.UserName ,
	       li.LoginIPAddress,
	       li.LoginDate,
	       li.Browser,
	       li.SystemPlatform,
	       li.RemoteIPAddress,
	       li.WindowsLoginUser,
	       li.TotalTimeInSeconds,
		   li.LoginInfoID,
		   li.TokenID
	   FROM LoginInfo li
	   INNER JOIN UserMaster UM ON UM.UserID = li.UserID
	   AND UM.IsActive = li.IsActive
	   INNER JOIN UserRole UR ON UR.UserID = UM.UserID
	   INNER JOIN ChildRoles ON ChildRoles.ParentRoleID = UR.RoleID
	   WHERE li.IsActive = 1
	   AND li.LoginIPAddress LIKE CONCAT(IFNULL(LoginIPAddress_ , li.LoginIPAddress) , '%')
	   AND UM.UserName LIKE CONCAT('%' , IFNULL(UserName_ , UM.UserName),'%');
       
       DROP TEMPORARY TABLE ChildRoles;
       DROP TEMPORARY TABLE ParentRole;
       DROP TEMPORARY TABLE ParentRole_Temp;
END ;;