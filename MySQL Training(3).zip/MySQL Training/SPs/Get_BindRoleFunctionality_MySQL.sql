DELIMITER ;;
CREATE DEFINER=`UM`@`%` PROCEDURE `Get_BindRoleFunctionality`(
       IN ServiceID       SMALLINT,
       IN ClientID        INT ,
       IN RoleID          INT,
       IN FunctionalityID INT ,
       IN ScreenID        INT ,
       OUT ReturnMessage   VARCHAR(1000) ,
       OUT RowCount        INT )
BEGIN
 /* 
	Procedure Header:
	+----------------------------------------------------------------------------------------------------+
	Procedure Name        [UM].[Get_BindRoleFunctionality]
	Purpose               Selects data from Role Functionality table based on parameters
	Created By            Mayank Kukadia
	Created Date          07/30/2015
	JIRA Id               --
	--------------------------Parameter Details------------------------------
	@ServiceID             SeriviceID for which functionalies will be fetched [Optional Parameter]
	@ClientID              ClientID for wich functionalies will be fetched  [Optional Parameter]
	@RoleID                RoleID for wich functionalies will be fetched  [Optional Parameter]
	@FunctionalityID	   FunctionalityID for wich functionalies will be fetched  [Optional Parameter]
	@ScreenID 			   SeriviceID for which functionalies will be fetched [Optional Parameter]
	@ReturnMessage         OUTPUT - returns output message of procedure
	@RowCount			   OUTPUT	- return numbers of row

	Note: Any one of    @ServiceID , @ClientID , @RoleID and @FunctionalityID is required
	+-----------------------------------------------------------------------------------------------------+
    
	Script with Sample parameters:
	+----------------------------------------------------------------------------+
		
        set @ServiceID = 4;
		set @ClientID = 0;
		set @RoleID = 0;
		set @FunctionalityID = 0;
		set @ScreenID = 0;
		set @ReturnMessage = '0';
		set @RowCount = 0;
		call qausermanagement.Get_BindRoleFunctionality(@ServiceID, @ClientID, @RoleID, @FunctionalityID, @ScreenID, @ReturnMessage, @RowCount);

	+----------------------------------------------------------------------------+

	Revision History:(Latest First)
	+--------------------------------------------------------------------------------------------------------------+
	Modified By        Modified Date  JIRA Id     Purpose
	-----------------  -------------- ----------- ------------------------
	Sameer Savsani	   12-09-2015				 Removed ClientService Table dependencie and add ClientMaster Join
	Ravi Gehlot	   04/12/2016			      Removed InsertedByName, UpdatedByName and UserMaster Joins
	+--------------------------------------------------------------------------------------------------------------+
	*/
    
     DECLARE ServiceID_ SMALLINT DEFAULT ServiceID;
     DECLARE ClientID_ INT DEFAULT IFNULL(ClientID, 0);
     DECLARE RoleID_ INT DEFAULT IFNULL(RoleID, 0);
     DECLARE FunctionalityID_ INT DEFAULT IFNULL(FunctionalityID, 0);
              
 	 DECLARE code CHAR(5) DEFAULT '00000';
     DECLARE msg TEXT;
 	    
 	 DECLARE EXIT HANDLER FOR SQLEXCEPTION
     BEGIN
       GET DIAGNOSTICS CONDITION 1
         code = RETURNED_SQLSTATE, msg = MESSAGE_TEXT;
         SET ReturnMessage = msg;
     END;
 
         SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    
         SET RowCount = 0;
         SET ReturnMessage = '';
 
        
 		SELECT Distinct ServiceMaster.ServiceID,
 			 ServiceMaster.ServiceName,
 			 ServiceMaster.DisplayName as ServiceDisplayName,		
             IFNULL(FunctionalityMaster.FunctionalityID,0) FunctionalityID,
             FunctionalityMaster.FunctionalityName,
             FunctionalityMaster.DisplayName AS FunctionalityDisplayName,
             IFNULL(ScreenMaster.ScreenID,0) ScreenID,
             ScreenMaster.ScreenName,
             ScreenMaster.DisplayName AS ScreenDisplayName,
             IFNULL(ScreenFunctionalityMaster.ScreenFunctionalityID,0) ScreenFunctionalityID,
             ScreenFunctionalityMaster.ScreenFunctionality AS ScreenFunctionalityName,
            -- CONCAT(IFNULL(InsertUserMaster.FirstName,''), ' ' , IFNULL(InsertUserMaster.LastName,'')) AS InsertedByName,
            -- CONCAT(IFNULL(UpdateUserMaster.FirstName,''), ' ' , IFNULL(UpdateUserMaster.LastName,'')) AS UpdatedByName,
 			 IFNULL(ClientMaster.ClientID, 0) AS ClientID
 		FROM ServiceMaster
  		INNER JOIN RoleMaster 
			On RoleMaster.ServiceID = ServiceMaster.ServiceID OR (RoleMaster.ParentRoleID IS NULL)
        INNER JOIN RoleFunctionality 
			ON RoleFunctionality.RoleID = RoleMaster.RoleID
        INNER JOIN FunctionalityMaster 
			ON FunctionalityMaster.FunctionalityID = RoleFunctionality.FunctionalityID AND FunctionalityMaster.ServiceID=ServiceMaster.ServiceID
        LEFT JOIN ScreenMaster 
			ON ScreenMaster.ScreenID = RoleFunctionality.ScreenID and RoleFunctionality.ScreenID IS NOT NULL AND ScreenMaster.FunctionalityID=FunctionalityMaster.FunctionalityID
        LEFT JOIN ScreenFunctionalityMaster 
			ON ScreenFunctionalityMaster.ScreenFunctionalityID = RoleFunctionality.ScreenFunctionalityID AND RoleFunctionality.ScreenFunctionalityID IS NOT NULL AND ScreenMaster.ScreenID=ScreenFunctionalityMaster.ScreenID
 		LEFT JOIN ClientMaster 
			ON ClientMaster.ServiceID = ServiceMaster.ServiceID
		-- LEFT JOIN UserMaster InsertUserMaster ON InsertUserMaster.UserID = RoleFunctionality.InsertedBy
        -- LEFT JOIN UserMaster UpdateUserMaster ON UpdateUserMaster.UserID = RoleFunctionality.InsertedBy
 		WHERE 
 			( 0 = RoleID_  OR RoleID_ = RoleMaster.RoleID )
 			AND (ServiceID_ = ServiceMaster.ServiceID OR (RoleMaster.ParentRoleID IS NULL));
 		
 		SET RowCount = Row_Count();
 
     END ;;