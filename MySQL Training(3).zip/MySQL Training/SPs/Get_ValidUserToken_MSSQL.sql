﻿CREATE PROCEDURE [UM].[Get_ValidUserToken]
	(
	@TokenID       UNIQUEIDENTIFIER = NULL,
	@ServiceID     SMALLINT = 0,
	@IPAddress	 varchar(256)=NULL,
	@UpdateSessionOnTokenValidation BIT=1,
	@ReturnMessage VARCHAR(1000) OUTPUT,
	@RowCount      INT OUTPUT 
	)
/*

	Script with Sample parameters:
	╔═══════════════════════════════════════════════════════════════════════╗
	EXEC [UM].[Get_ValidUserToken]  
	@TokenID='00000000-0000-0000-0000-000000000000'
	@ServiceID	=3,	
	@IPAddress ='198.168.50.5',	    
	@UpdateSessionOnTokenValidation 1,
	@ReturnMessage ='',
	@RowCount =0		
	╚═══════════════════════════════════════════════════════════════════════╝

*/

AS
BEGIN
    SET NOCOUNT OFF;
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    SET @ReturnMessage = '';
    SET @RowCount = 0;
    DECLARE @TokenID_ UNIQUEIDENTIFIER = @TokenID;
    DECLARE @ServiceID_ SMALLINT = @ServiceID;
    DECLARE @IPAddress_ VARCHAR(256) = ISNULL(@IPAddress, '')
    DECLARE @CurrentTime_ DATETIME = UM.GetCurrentDate(0);
    DECLARE @SessionTimeoutMinutes_ SMALLINT = 0;
    DECLARE @UpdateSessionOnTokenValidation_ AS BIT = ISNULL(@UpdateSessionOnTokenValidation,1)
    DECLARE @LoginInfoID BIGINT = 0;
    DECLARE @UserID INT = 0;
    DECLARE @RecentVisitTime DATETIME;
	DECLARE @AffectedRows int;

    BEGIN TRY
	   -- Get User details from TOken
	   SELECT TOP 1
		  @LoginInfoID = LoginInfoID,
		  @RecentVisitTime = RecentVisitTime,
		  @UserID = UserID
	   FROM [UM].LoginInfo
	   WHERE IsActive = 1
		  AND TokenID = @TokenID_
		  AND (@IPAddress_ = '' OR IPAddress = @IPAddress_)
	   ORDER BY 
		  LoginInfoID DESC

	   IF (ISNULL(@LoginInfoID, 0) > 0)  --- Update Recent Visit in case of token check in system
	   BEGIN
		  SELECT TOP 1
			 @SessionTimeoutMinutes_ = MIN(CSS.SessionTimeoutInMinutes)
		  FROM UM.ClientUser CU
			 INNER JOIN UM.ClientService CS 
				ON CS.ClientServiceID = CU.ClientServiceID AND CS.IsActive = 1
			 INNER JOIN UM.ClientSessionSettings CSS 
				ON CSS.ClientServiceID = CU.ClientServiceID
		  WHERE UserID = @UserID
			 AND (@ServiceID_ = 0 OR @ServiceID_ = CS.ServiceID );

		  IF @SessionTimeoutMinutes_ = 0 
		  BEGIN
			 SELECT TOP 1
				@SessionTimeoutMinutes_ = SS.SessionTimeoutInMinutes
			 FROM UM.UserRole UR
			 INNER JOIN um.RoleMaster RM 
				ON RM.RoleID = UR.RoleID
			 INNER JOIN UM.SessionSettings SS 
				ON SS.ServiceID = RM.ServiceID
			 WHERE UR.UserID = @UserID
			 ORDER BY CASE
				WHEN @ServiceID_ = RM.ServiceID THEN 1
				ELSE 2
				END, SS.SessionTimeoutInMinutes;
		  END;
		  ELSE 
		  BEGIN
			 SET @SessionTimeoutMinutes_ = 60
		  END;

		  IF DATEADD(MINUTE, @SessionTimeoutMinutes_, @RecentVisitTime) < @CurrentTime_ 
		  BEGIN
		  -- deactivate token using timeout settings
			 UPDATE [UM].LoginInfo
				SET IsActive = 0
			 WHERE LoginInfoID = @LoginInfoID;

			 SET @AffectedRows = @@ROWCOUNT

			 RETURN;
		  END; 
		  ELSE 
		  BEGIN
			 -- found Valid token then update recent visit time
			 UPDATE [UM].LoginInfo
				SET RecentVisitTime = @CurrentTime_
			 WHERE LoginInfoID = @LoginInfoID
				AND @UpdateSessionOnTokenValidation_=1;
				
				SET @AffectedRows = @@ROWCOUNT

		  END;
	   END; 
	   ELSE 
	   BEGIN
		  -- Token already deactivated by system due to time out 
		  RETURN;
	   END;

	   SELECT TOP 1
		  LoginInfoID,
		  UserID,
		  LoginIPAddress,
		  LandingIPAddress,
		  IPAddress,
		  SessionID,
		  TokenID,
		  LoginDate,
		  LogoffDate,
		  Browser,
		  SystemPlatform,
		  LoginStatusID,
		  RemoteIPAddress,
		  WindowsLoginUser,
		  TotalTimeInSeconds,
		  IsActive,
		  InsertedBy,
		  InsertedDate,
		  ModifiedBy,
		  ModifiedDate
	   FROM [UM].LoginInfo
	   WHERE LoginInfoID = @LoginInfoID;
	   
	   SET @RowCount = @@ROWCOUNT;

	   SELECT @AffectedRows,@RowCount
	   
    END TRY 
    BEGIN CATCH
	   SET @ReturnMessage = 'Error is occured';
    END CATCH;
 END;

