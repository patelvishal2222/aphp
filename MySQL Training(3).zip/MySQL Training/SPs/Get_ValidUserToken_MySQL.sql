DELIMITER ;;
CREATE DEFINER=`UM`@`%` PROCEDURE `Get_ValidUserToken`(
 		IN TokenID       VARCHAR(64),
 		IN ServiceID     SMALLINT,
 		IN IPAddress	 VARCHAR(256),
 		IN UpdateSessionOnTokenValidation TINYINT(1),
 		OUT ReturnMessage VARCHAR(1000),
 		OUT RowCount      INT
 	)
root:BEGIN
 
 
 	DECLARE RecentVisitTime_ DATETIME;
 
 	DECLARE TokenID_ 							VARCHAR(64) 	DEFAULT TokenID;
 	DECLARE ServiceID_ 							SMALLINT 		DEFAULT IFNULL(ServiceID,0);
 	DECLARE IPAddress_ 							VARCHAR(256) 	DEFAULT IFNULL(IPAddress, '');
 	DECLARE CurrentTime_ 						DATETIME 		DEFAULT GETCURRENTDATE(0);
 	DECLARE UpdateSessionOnTokenValidation_  	TINYINT(1) 		DEFAULT IFNULL(UpdateSessionOnTokenValidation,1);
 	DECLARE LoginInfoID_ 						BIGINT 			DEFAULT 0;
 	DECLARE UserID_ 							INT 			DEFAULT 0;
  
 	DECLARE code CHAR(5) DEFAULT '00000';
 	DECLARE msg TEXT; 
 	DECLARE EXIT HANDLER FOR SQLEXCEPTION
 	BEGIN
 	GET DIAGNOSTICS CONDITION 1
 	code = RETURNED_SQLSTATE, msg = MESSAGE_TEXT;
 	SET ReturnMessage = msg;
 	END;   
 	
 	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;   
 	SET ReturnMessage = '';
 	SET RowCount = 0;
     
        
 	 
 	SELECT 
 	LoginInfoID,
 	RecentVisitTime,
 	UserID
 	INTO LoginInfoID_,RecentVisitTime_,UserID_
    FROM
 	LoginInfo
 	WHERE 
 	LoginInfo.IsActive = 1
 	AND LoginInfo.TokenID = TokenID_
 	AND (IPAddress_ = '' OR LoginInfo.IPAddress = IPAddress_)
 	ORDER BY 
 	LoginInfo.LoginInfoID DESC LIMIT 1;
 
 
    IF (IFNULL(LoginInfoID_, 0) > 0)  
    THEN
    	SELECT MIN(CSS.SessionTimeoutInMinutes) INTO  @SessionTimeoutMinutes 
 		FROM  ClientUser CU
 		INNER JOIN ClientService CS ON CS.ClientServiceID = CU.ClientServiceID AND CS.IsActive = 1
 		INNER JOIN ClientSessionSettings CSS ON CSS.ClientServiceID = CU.ClientServiceID
 		WHERE UserID = UserID_
 		AND (ServiceID_ = 0 OR ServiceID_ = CS.ServiceID )
 		LIMIT 1;
 
 		IF @SessionTimeoutMinutes = 0 
 		THEN
 			SELECT  SS.SessionTimeoutInMinutes INTO 	@SessionTimeoutMinutes 
 			FROM UserRole UR
 			INNER JOIN RoleMaster RM ON RM.RoleID = UR.RoleID
 			INNER JOIN SessionSettings SS ON SS.ServiceID = RM.ServiceID
 			WHERE	UR.UserID = UserID
 			ORDER BY CASE	WHEN ServiceID_ = RM.ServiceID THEN 1	ELSE 2	END, SS.SessionTimeoutInMinutes  LIMIT 1;
 		ELSE 
 			SET @SessionTimeoutMinutes = 60;
 		END IF;
 
 		IF DATE_ADD(RecentVisitTime_,INTERVAL @SessionTimeoutMinutes MINUTE) < CurrentTime_ 
 		THEN 
 		
 			UPDATE LoginInfo
 			SET IsActive = 0
 			WHERE	LoginInfoID = LoginInfoID_;
 			LEAVE root; 
 		ELSE 
 			
 			UPDATE 	LoginInfo
 			SET	RecentVisitTime = CurrentTime_
 			WHERE	LoginInfoID = LoginInfoID_	AND UpdateSessionOnTokenValidation_=1;
 		END IF;
 			    
    ELSE    
 	  
 	  LEAVE root; 
    END IF;
 
    SELECT 
 	  LoginInfoID,
 	  UserID,
 	  LoginIPAddress,
 	  LandingIPAddress,
 	  IPAddress,
 	  SessionID,
 	  TokenID,
 	  LoginDate,
 	  LogoffDate,
 	  Browser,
 	  SystemPlatform,
 	  LoginStatusID,
 	  RemoteIPAddress,
 	  WindowsLoginUser,
 	  TotalTimeInSeconds,
 	  IsActive,
 	  InsertedBy,
 	  InsertedDate,
 	  ModifiedBy,
 	  ModifiedDate
    FROM 
 		LoginInfo
    WHERE 
 	  LoginInfo.LoginInfoID = LoginInfoID_ LIMIT 1;
    
    SET RowCount = ROW_COUNT();
    
    
 END ;;