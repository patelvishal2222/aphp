﻿CREATE  PROCEDURE [UM].[Get_BindRoleFunctionality](
      @ServiceID       SMALLINT,
      @ClientID        INT = NULL,
      @RoleID          INT,
      @FunctionalityID INT = NULL,
      @ScreenID        INT = NULL,
      @ReturnMessage   VARCHAR(1000) OUTPUT,
      @RowCount        INT OUTPUT )
AS
	/*
	
	Script with Sample parameters:
	╔════════════════════════════════════════════════════════════════════════════╗
	EXEC [UM].[Get_BindRoleFunctionality]  
	@ServiceID =3,
	@ClientID=0,
	@RoleID=0,
	@FunctionalityID=0,
	@ScreenID =0,  
	@ReturnMessage = '',
	@RowCount = 0
	╚════════════════════════════════════════════════════════════════════════════╝

	*/

    BEGIN
        SET NOCOUNT ON;
        SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    BEGIN TRY
        SET @RowCount = 0;
        SET @ReturnMessage = '';
        DECLARE @ServiceID_ SMALLINT = @ServiceID;
        DECLARE @ClientID_ INT = ISNULL(@ClientID, 0);
        DECLARE @RoleID_ INT = ISNULL(@RoleID, 0);
        DECLARE @FunctionalityID_ INT = ISNULL(@FunctionalityID, 0);
        
		SELECT Distinct UM.ServiceMaster.ServiceID,
			UM.ServiceMaster.ServiceName,
			UM.ServiceMaster.DisplayName as ServiceDisplayName,		----Added For DisplayName of ServiceMas
            ISNULL(UM.FunctionalityMaster.FunctionalityID,0) FunctionalityID,
            UM.FunctionalityMaster.FunctionalityName,
            UM.FunctionalityMaster.DisplayName AS FunctionalityDisplayName,
            ISNULL(UM.ScreenMaster.ScreenID,0) ScreenID,
            UM.ScreenMaster.ScreenName,
            UM.ScreenMaster.DisplayName AS ScreenDisplayName,
            ISNULL(UM.ScreenFunctionalityMaster.ScreenFunctionalityID,0) ScreenFunctionalityID,
            UM.ScreenFunctionalityMaster.ScreenFunctionality AS ScreenFunctionalityName,
			ISNULL(UM.ClientMaster.ClientID, 0) AS ClientID
		FROM UM.ServiceMaster
			INNER JOIN UM.RoleMaster On UM.RoleMaster.ServiceID = UM.ServiceMaster.ServiceID OR (UM.RoleMaster.ParentRoleID IS NULL)
            INNER JOIN UM.RoleFunctionality ON UM.RoleFunctionality.RoleID = UM.RoleMaster.RoleID
            INNER JOIN UM.FunctionalityMaster ON UM.FunctionalityMaster.FunctionalityID = UM.RoleFunctionality.FunctionalityID AND UM.FunctionalityMaster.ServiceID=UM.ServiceMaster.ServiceID
			 AND UM.FunctionalityMaster.IsDeleted = 0
		  LEFT JOIN UM.ScreenMaster ON UM.ScreenMaster.ScreenID = UM.RoleFunctionality.ScreenID and UM.RoleFunctionality.ScreenID IS NOT NULL AND UM.ScreenMaster.FunctionalityID=UM.FunctionalityMaster.FunctionalityID
			 AND UM.ScreenMaster.IsActive = 1 AND UM.ScreenMaster.IsDeleted = 0
		  LEFT JOIN UM.ScreenFunctionalityMaster ON UM.ScreenFunctionalityMaster.ScreenFunctionalityID = UM.RoleFunctionality.ScreenFunctionalityID AND UM.RoleFunctionality.ScreenFunctionalityID IS NOT NULL AND UM.ScreenMaster.ScreenID=UM.ScreenFunctionalityMaster.ScreenID
			 AND UM.ScreenFunctionalityMaster.IsDeleted = 0
		  LEFT JOIN UM.ClientMaster ON UM.ClientMaster.ServiceID = UM.ServiceMaster.ServiceID
		WHERE UM.ServiceMaster.ServiceID = @ServiceID_
			AND UM.ServiceMaster.IsDeleted = 0
			AND ( 0 = @RoleID_  OR @RoleID_ = UM.RoleMaster.RoleID )
			
		SET @RowCount = @@RowCount;
    END TRY
    BEGIN CATCH
        SET @ReturnMessage = [UM].GetErrorDetails();
    END CATCH;
    END;


