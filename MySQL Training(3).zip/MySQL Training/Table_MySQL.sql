CREATE TABLE `UserRole` (
  `UserRoleID` int(11) NOT NULL AUTO_INCREMENT, -- PRIMARY KEY
  `UserID` int(11) NOT NULL,
  `ServiceID` smallint(6) NOT NULL DEFAULT '0',
  `RoleID` int(11) NOT NULL,
  `InsertedBy` int(11) NOT NULL,
  `InsertedDate` date NOT NULL,
  PRIMARY KEY (`UserRoleID`),
  FOREIGN KEY (UserID) REFERENCES UserMaster(UserID),
  KEY `UserRole__UserMaster` (`UserID`),
  KEY `UserRole__RoleMaster` (`RoleID`)
) ;

-- Indexes
SHOW INDEXES FROM UserRole;

-- Ressed identity
ALTER TABLE UserRole AUTO_INCREMENT = 100;

-- Linked Server
CREATE TABLE federated_table (
    id     INT(20) NOT NULL AUTO_INCREMENT,
    name   VARCHAR(32) NOT NULL DEFAULT '',
    other  INT(20) NOT NULL DEFAULT '0',
    PRIMARY KEY  (id),
    INDEX name (name),
    INDEX other_key (other)
)
ENGINE=FEDERATED
DEFAULT CHARSET=latin1
CONNECTION='mysql://fed_user@remote_host:9306/federated/test_table';